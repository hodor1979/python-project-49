import prompt
from random import randint   # числа для игры будут генерироваться случайно

print('Answer "yes" if the number is even, otherwise answer "no".')
for i in range(0, 3):
  x = randint(1, 100)
  if x % 2 == 0:
   correct_answer = "yes"
  else:
    correct_answer = "no"
user_answer = prompt.string('Question: 'x)
