### Hexlet tests and linter status:
[![Actions Status](https://github.com/hodor1979/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hodor1979/python-project-49/actions)
### codeclimate maintability
[![Maintainability](https://api.codeclimate.com/v1/badges/1159b9c881f96dddd119/maintainability)](https://codeclimate.com/github/hodor1979/python-project-49/maintainability)