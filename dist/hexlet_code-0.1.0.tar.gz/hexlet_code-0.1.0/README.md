### A set of 5 maths games named "Brain Games" consistinf of :
### brain-calc ->  player does calculation
### brain-even ->  player considers if a number is even
### brain-gcd ->  player finds the greatest common divisor
### brain-prime ->  player considers if a number is prime
### brain-progression ->  player finds missing number in a progression

### Hexlet tests and linter status:
[![Actions Status](https://github.com/hodor1979/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hodor1979/python-project-49/actions)
### codeclimate maintability
[![Maintainability](https://api.codeclimate.com/v1/badges/1159b9c881f96dddd119/maintainability)](https://codeclimate.com/github/hodor1979/python-project-49/maintainability)
### Asciinema record
[![asciicast](https://asciinema.org/a/561069.svg)](https://asciinema.org/a/561069)
