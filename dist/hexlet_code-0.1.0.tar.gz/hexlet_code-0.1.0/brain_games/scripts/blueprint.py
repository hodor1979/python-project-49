print(__file__)
